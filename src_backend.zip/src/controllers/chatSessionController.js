const { db } = require('../config/firebase');
const { decrypt } = require('../utils/encryption');

/* START chat session */
exports.startChatSession = (req, res) => {
  const { booking_id } = req.body;

  if (!booking_id) {
    return res.status(400).json({ message: 'booking_id is required' });
  }

  const sql = `
    INSERT INTO chat_sessions (booking_id, chat_type, status)
    VALUES (?, 'scheduled', 'active')
  `;

  db.query(sql, [booking_id], (err, result) => {
    if (err) return res.status(400).json(err);
    res.status(201).json({
      message: 'Chat session started',
      chat_id: result.insertId
    });
  });
};

/* END chat session */
exports.endChatSession = (req, res) => {
  const { chat_id } = req.params;

  const sql = `
    UPDATE chat_sessions
    SET status = 'closed', ended_at = NOW(), ended_reason = 'manual'
    WHERE chat_id = ?
  `;

  db.query(sql, [chat_id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Chat session ended' });
  });
};

/* GET sessions for current user */
exports.getSessions = async (req, res) => {
  try {
    // 🔥 Flexible user detection (don't trust your auth blindly)
    const userId =
      req.user?.student_id ||
      req.user?.counselor_id ||
      req.user?.id ||
      req.query.user_id;

    if (!userId) {
      return res.status(400).json({ message: "User ID missing" });
    }

    const [rows] = await db.promise().query(
      `
      SELECT 
        cs.chat_id,
        cs.student_id,
        cs.counselor_id,
        cs.status,

        -- 👤 Other person's name
        CASE 
          WHEN cs.student_id = ? 
            THEN CONCAT(c.first_name, ' ', c.last_name)
          ELSE CONCAT(s.first_name, ' ', s.last_name)
        END AS other_name,

        -- 🧠 Last message (raw encrypted)
        (
          SELECT cm.encrypted_message
          FROM chat_messages cm
          WHERE cm.chat_id = cs.chat_id
          ORDER BY cm.sent_at DESC
          LIMIT 1
        ) AS last_message,

        -- ⏱ Last message time
        (
          SELECT cm.sent_at
          FROM chat_messages cm
          WHERE cm.chat_id = cs.chat_id
          ORDER BY cm.sent_at DESC
          LIMIT 1
        ) AS last_time

      FROM chat_sessions cs

      LEFT JOIN counselors c 
        ON cs.counselor_id = c.counselor_id

      LEFT JOIN student_details s 
        ON cs.student_id = s.student_id

      WHERE cs.student_id = ? OR cs.counselor_id = ?

      ORDER BY last_time DESC
      `,
      [userId, userId, userId]
    );

    // ⚠️ Clean output for frontend (VERY important)
    const sessions = rows.map((row) => ({
      chat_id: row.chat_id,
      other_name: row.other_name || "Unknown",
      last_message: row.last_message ? "New message" : "No messages yet",
      last_time: row.last_time,
      unread: 0, // can upgrade later
      status: row.status,
    }));

    return res.json(sessions);

  } catch (err) {
    console.error("❌ getSessions error:", err);
    return res.status(500).json({ message: "Failed to fetch sessions" });
  }
};