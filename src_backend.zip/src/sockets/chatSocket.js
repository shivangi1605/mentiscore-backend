// const db = require("../config/db"); /
const { encrypt } = require("../utils/encryption");

module.exports = (io) => {
  io.on("connection", (socket) => {
    console.log("🔌 Socket connected:", socket.id);

    /* ================= JOIN USER ================= */
    socket.on("join", (payload) => {
      const userId = payload?.user_id ?? payload?.userId ?? payload;

      if (!userId) {
        return socket.emit("errorMessage", "User ID required");
      }

      socket.join(`user_${userId}`);
      console.log(`User ${userId} joined personal room`);
    });

    /* ================= JOIN CHAT ================= */
    socket.on("joinChat", async (payload) => {
      const chatId = payload?.chat_id ?? payload?.chatId ?? payload?.room;
      const userId = payload?.user_id ?? payload?.userId;

      if (!chatId || !userId) {
        console.error("❌ joinChat missing data");
        return;
      }

      try {
        const [rows] = await db.promise().query(
          `
          SELECT student_id, counselor_id, status
          FROM chat_sessions
          WHERE chat_id = ?
          `,
          [chatId]
        );

        const chat = rows[0];

        if (!chat) {
          console.error("❌ Chat not found");
          return;
        }

        // 🔒 Block joining closed chats
        if (chat.status !== "active") {
          console.error("❌ Cannot join closed chat");
          return;
        }

        // 🔒 Strict user validation (number-safe)
        if (
          Number(chat.student_id) !== Number(userId) &&
          Number(chat.counselor_id) !== Number(userId)
        ) {
          console.error("❌ Unauthorized join attempt");
          return;
        }

        socket.join(`chat_${chatId}`);
        console.log(`User ${userId} joined chat_${chatId}`);

      } catch (err) {
        console.error("❌ joinChat error:", err);
      }
    });

    /* ================= SEND MESSAGE ================= */
    socket.on("sendMessage", async (payload) => {
      const chatId = payload?.chat_id ?? payload?.chatId ?? payload?.room;
      const { sender_role, sender_id, message } = payload || {};

      if (!chatId || !sender_role || !sender_id || !message?.trim()) {
        console.error("❌ Invalid payload", payload);
        return;
      }

      try {
        // 🔒 Validate chat session
        const [chatRows] = await db.promise().query(
          `
          SELECT student_id, counselor_id, status
          FROM chat_sessions
          WHERE chat_id = ?
          `,
          [chatId]
        );

        const chat = chatRows[0];

        if (!chat) {
          console.error("❌ Chat not found");
          return;
        }

        // 🔒 Block closed chats
        if (chat.status !== "active") {
          console.error("❌ Chat is closed");
          return;
        }

        // 🔒 Strict role-based validation (NUMBER SAFE)
        if (
          (sender_role === "student" && Number(chat.student_id) !== Number(sender_id)) ||
          (sender_role === "counselor" && Number(chat.counselor_id) !== Number(sender_id))
        ) {
          console.error("❌ Unauthorized sender");
          return;
        }

        // 🔐 Encrypt message
        const encryptedMessage = encrypt(message);

        // 💾 Save to DB
        const [result] = await db.promise().query(
          `
          INSERT INTO chat_messages
          (chat_id, sender_role, sender_id, encrypted_message)
          VALUES (?, ?, ?, ?)
          `,
          [chatId, sender_role, sender_id, encryptedMessage]
        );

        const messageData = {
          message_id: result.insertId,
          chat_id: chatId,
          sender_role,
          sender_id,
          message, // plaintext for frontend
          sent_at: new Date()
        };

        // 📡 Emit to chat room
        io.to(`chat_${chatId}`).emit("receiveMessage", messageData);

        // 📡 ALSO emit to user rooms (important for sidebar updates)
        io.to(`user_${chat.student_id}`).emit("newMessage", messageData);
        io.to(`user_${chat.counselor_id}`).emit("newMessage", messageData);

      } catch (err) {
        console.error("❌ sendMessage error:", err);
      }
    });

    /* ================= TYPING ================= */
    socket.on("typing", (payload) => {
      const chatId = payload?.chat_id ?? payload?.chatId ?? payload?.room;
      const { sender_role } = payload || {};

      if (!chatId) return;

      socket.to(`chat_${chatId}`).emit("userTyping", { sender_role });
    });

    socket.on("stopTyping", (payload) => {
      const chatId = payload?.chat_id ?? payload?.chatId ?? payload?.room;
      const { sender_role } = payload || {};

      if (!chatId) return;

      socket.to(`chat_${chatId}`).emit("userStoppedTyping", { sender_role });
    });

    /* ================= DISCONNECT ================= */
    socket.on("disconnect", () => {
      console.log("❌ Socket disconnected:", socket.id);
    });
  });
};